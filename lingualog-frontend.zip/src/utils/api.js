// src/utils/api.js

const API_BASE_URL = 'http://localhost:3000'; // Adjust the base URL as needed

// Helper function to handle responses
const handleResponse = async (response) => {
    if (!response.ok) {
        const message = `An error has occurred: ${response.statusText}`;
        throw new Error(message);
    }
    return response.json();
};

// Helper function to handle errors
const handleError = (error) => {
    console.error('API call failed:', error);
    throw error;
};

// Fetch all diary entries
export const fetchDiaryEntries = async () => {
    return fetch(`${API_BASE_URL}/diaryEntries`)
        .then(handleResponse)
        .catch(handleError);
};

// Fetch a single diary entry by ID
export const fetchDiaryEntryById = async (id) => {
    return fetch(`${API_BASE_URL}/diaryEntries/${id}`)
        .then(handleResponse)
        .catch(handleError);
};

// Create a new diary entry
export const createDiaryEntry = async (entryData) => {
    return fetch(`${API_BASE_URL}/diaryEntries`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(entryData),
    }).then(handleResponse)
      .catch(handleError);
};

// Update an existing diary entry
export const updateDiaryEntry = async (id, entryData) => {
    return fetch(`${API_BASE_URL}/diaryEntries/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(entryData),
    }).then(handleResponse)
      .catch(handleError);
};

// Delete a diary entry
export const deleteDiaryEntry = async (id) => {
    return fetch(`${API_BASE_URL}/diaryEntries/${id}`, {
        method: 'DELETE'
    }).then(handleResponse)
      .catch(handleError);
};

// User registration
export const registerUser = async (userData) => {
    return fetch(`${API_BASE_URL}/users/register`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
    }).then(handleResponse)
      .catch(handleError);
};

// User login
export const loginUser = async (credentials) => {
    return fetch(`${API_BASE_URL}/users/login`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(credentials),
    }).then(handleResponse)
      .catch(handleError);
};