import axios from 'axios';

const API_URL = 'http://localhost:5001/api/auth'; // Update with your actual API URL

class AuthService {
  async login(username, password) {
    const response = await axios.post(`${API_URL}/login`, { username, password });
    if (response.data.token) {
      localStorage.setItem('user', JSON.stringify(response.data));
      console.log(JSON.parse(localStorage.getItem('user')))
    }
    return response.data;
  }

  async signup(username, email, password) {
    const response = await axios.post(`${API_URL}/signup`, { username, email, password });
    console.log("Received signup response", response.data);
    return response.data;
  }

  logout() {
    localStorage.removeItem('user');
  }

  getCurrentUser() {
    return JSON.parse(localStorage.getItem('user'));
  }
}

const authService = new AuthService();
export default authService;