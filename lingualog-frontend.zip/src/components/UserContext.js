// import { createContext, useContext, useState, useEffect } from 'react';
// import AuthService from '../services/AuthService'; // Ensure this path is correct

// const UserContext = createContext(null);

// export const UserProvider = ({ children }) => {
//     const [user, setUser] = useState(AuthService.getCurrentUser());

//     useEffect(() => {
//         // Sync user data with local storage changes
//         const handleStorageChange = () => {
//             setUser(AuthService.getCurrentUser());
//         };

//         window.addEventListener('storage', handleStorageChange);

//         return () => {
//             window.removeEventListener('storage', handleStorageChange);
//         };
//     }, []);

//     return (
//         <UserContext.Provider value={{ user, setUser }}>
//             {children}
//         </UserContext.Provider>
//     );
// };

// export const useUser = () => useContext(UserContext);

import { createContext, useContext, useState, useEffect } from 'react';
import AuthService from '../services/AuthService'; // Ensure this path is correct

const UserContext = createContext(null);

export const UserProvider = ({ children }) => {
    const [user, setUser] = useState(() => {
        return AuthService.getCurrentUser() || null; // Ensure it falls back to null if undefined
    });

    useEffect(() => {
        const handleStorageChange = () => {
            setUser(AuthService.getCurrentUser() || null);
        };

        window.addEventListener('storage', handleStorageChange);

        return () => {
            window.removeEventListener('storage', handleStorageChange);
        };
    }, []);

    return (
        <UserContext.Provider value={{ user, setUser }}>
            {children}
        </UserContext.Provider>
    );
};

export const useUser = () => useContext(UserContext);