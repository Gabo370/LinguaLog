// DiaryPageStyles.js
import styled from 'styled-components';

export const PageContainer = styled.div`
  padding: 20px;
  font-family: Arial, sans-serif;
`;

export const Heading = styled.h1`
  color: #333;
`;

export const SubHeading = styled.h2`
  color: #555;
`;

export const PromptButton = styled.button`
  margin: 10px 0;
  padding: 10px 20px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
`;

export const PromptOutput = styled.span`
  margin-left: 20px;
  font-size: 16px;
`;

export const TextArea = styled.textarea`
  width: 100%;
  height: 150px;
  margin-top: 20px;
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
`;

export const SubmitButton = styled.button`
  display: block;
  width: 100%;
  padding: 10px 0;
  margin-top: 10px;
  background-color: #008CBA;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
`;