import React, { useState } from 'react';
import AuthService from '../services/AuthService'; // Ensure this path is correct
import './AuthForm.css';
import { useNavigate } from 'react-router-dom'; // Import useNavigate


const SignUp = () => {
    const [userData, setUserData] = useState({
        username: '',
        email: '',
        password: '',
    });
    const [message, setMessage] = useState('');
    const navigate = useNavigate();
    const handleChange = (e) => {
        console.log("Input change:", e.target.name, e.target.value);
        setUserData({ ...userData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log("Submitting data:", userData);
        try {
            const response = await AuthService.signup(userData.username, userData.email, userData.password);
            console.log("Signup response:", response);
            setMessage('Signup successful: ' + response.message);
            navigate('/diary');
        } catch (error) {
            console.error("Signup error:", error.response?.data?.message || 'Server error');
            setMessage('Signup failed: ' + (error.response?.data?.message || 'Server error'));
        }
    };

    return (
        <div className="auth-form">
            <h2>Sign Up</h2>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    name="username"
                    placeholder="Username"
                    value={userData.username}
                    onChange={handleChange}
                    required
                />
                <input
                    type="email"
                    name="email"
                    placeholder="Email"
                    value={userData.email}
                    onChange={handleChange}
                    required
                />
                <input
                    type="password"
                    name="password"
                    placeholder="Password"
                    value={userData.password}
                    onChange={handleChange}
                    required
                />
                <button type="submit">Sign Up</button>
                {message && <p>{message}</p>}
            </form>
        </div>
    );
};

export default SignUp;