// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import AuthService from '../services/AuthService'; // Ensure this path is correct
// import './AuthForm.css';
// import { useUser } from './UserContext';

// const Login = () => {
//     const [credentials, setCredentials] = useState({
//         username: '',
//         password: '',
//     });
//     const [message, setMessage] = useState('');
//     const navigate = useNavigate();
//     const { setUser } = useUser();
//     const handleChange = (e) => {
//         setCredentials({ ...credentials, [e.target.name]: e.target.value });
//     };

//     const handleSubmit = async (e) => {
//         e.preventDefault();
//         try {
//             const response = await AuthService.login(credentials.username, credentials.password);
//             setUser(AuthService.getCurrentUser()); // Update user context after successful login
//             setMessage('Login successful');
//             navigate('/diary'); // Update this route as necessary
//         } catch (error) {
//             setMessage('Login failed: ' + (error.response?.data?.message || 'Invalid credentials'));
//         }
//     };

//     return (
//         <div className="auth-form">
//             <h2>Log In</h2>
//             <form onSubmit={handleSubmit}>
//                 <input
//                     type="text"
//                     name="username"
//                     placeholder="Username"
//                     value={credentials.username}
//                     onChange={handleChange}
//                     required
//                 />
//                 <input
//                     type="password"
//                     name="password"
//                     placeholder="Password"
//                     value={credentials.password}
//                     onChange={handleChange}
//                     required
//                 />
//                 <button type="submit">Log In</button>
//                 {message && <p>{message}</p>}
//                 <p>
//                     Need an account? <a href="/signup">Sign Up</a>
//                 </p>
//             </form>
//         </div>
//     );
// };

// export default Login;
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthService from '../services/AuthService'; // Adjust path as needed
import { useUser } from './UserContext'; // Adjust path as needed
import './AuthForm.css'; // Adjust path as needed

const Login = () => {
    const [credentials, setCredentials] = useState({
        username: '',
        password: '',
    });
    const [message, setMessage] = useState('');
    const navigate = useNavigate();
    const { setUser } = useUser();

    const handleChange = (e) => {
        setCredentials({ ...credentials, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const data = await AuthService.login(credentials.username, credentials.password);
            setUser(data); // Update context
            setMessage('Login successful');
            navigate('/diary');
        } catch (error) {
            setMessage('Login failed: ' + (error.response?.data?.message || 'Invalid credentials'));
        }
    };

    return (
        <div className="auth-form">
            <h2>Log In</h2>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    name="username"
                    placeholder="Username"
                    value={credentials.username}
                    onChange={handleChange}
                    required
                />
                <input
                    type="password"
                    name="password"
                    placeholder="Password"
                    value={credentials.password}
                    onChange={handleChange}
                    required
                />
                <button type="submit">Log In</button>
                {message && <p>{message}</p>}
                <p>Need an account? <a href="/signup">Sign Up</a></p>
            </form>
        </div>
    );
};

export default Login;