import React, { useState } from 'react';
import { useUser } from './UserContext';

const DiaryPage = () => {
    const { user } = useUser();
    const [prompt, setPrompt] = useState('');
    const [entry, setEntry] = useState('');

    const handlePrompt = () => {
        const prompts = [
            "What are you grateful for today?",
            "Describe a memorable event from this week.",
            "What are your goals for the next month?",
        ];
        setPrompt(prompts[Math.floor(Math.random() * prompts.length)]);
    };

    const handleSubmit = () => {
        console.log('Submitting:', entry);
        setEntry(''); // Reset entry after submit
    };

    return (
        <div style={{ padding: '20px' }}>
            <h1>Welcome to your diary, {user ? user.username : 'Guest'}</h1>
            <h2>Hello there, {user ? user.username : 'Guest'}</h2> {/* Ensure user or 'Guest' is displayed */}
            <h2>Write your heart out</h2>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
                <button onClick={handlePrompt}>Prompt Generator</button>
                <span style={{ marginLeft: '20px' }}>{prompt}</span>
            </div>
            <textarea
                value={entry}
                onChange={(e) => setEntry(e.target.value)}
                placeholder="Write your journal entry here..."
                style={{ width: '100%', height: '150px', marginBottom: '10px' }}
            />
            <button onClick={handleSubmit}>Submit</button>
        </div>
    );
};

export default DiaryPage;