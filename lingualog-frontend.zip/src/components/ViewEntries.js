import React, { useEffect, useState } from 'react';

const ViewEntries = ({ userName }) => {
    const [entries, setEntries] = useState([]);

    useEffect(() => {
        // Fetch entries from the database
        // This is just a placeholder, replace with actual API call
        setEntries([
            { id: 1, content: "Today I'm grateful for..." },
            { id: 2, content: "A memorable event this week was..." }
        ]);
    }, []);

    return (
        <div>
            <h1>All Entries for {userName}</h1>
            {entries.map(entry => (
                <div key={entry.id}>
                    <p>{entry.content}</p>
                </div>
            ))}
        </div>
    );
};

export default ViewEntries;