import React from 'react';
import './LandingPage.css'; // Ensure this path is correct based on your file structure
import { useNavigate } from 'react-router-dom'; // Import useNavigate

const LandingPage = () => {
    const navigate = useNavigate(); // Initialize useNavigate

    return (
        <div className="landing-page">
            <header>
                <h1>Welcome to LinguaLog!</h1>
                <p>Diary Your Way to Fluency</p>
            </header>
            <main>
                <section>
                    <h2>Improve Your Language Skills</h2>
                    <p>Practice writing and speaking with immediate feedback.</p>
                </section>
                <section>
                    <h2>Join Our Community</h2>
                    <p>Learn and grow with others. Share your progress and get support from a community of language learners just like you.</p>
                </section>
            </main>
            <footer>
                <button onClick={() => navigate('/login')}>Get Started</button> {/* Updated to use navigate */}
            </footer>
        </div>
    );
};

export default LandingPage;