import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { UserProvider } from './components/UserContext'; // Import UserProvider
import LandingPage from './components/LandingPage';
import SignUp from './components/SignUp';
import Login from './components/Login';
import DiaryPage from './components/DiaryPage';
import ViewEntries from './components/ViewEntries';

function App() {
    return (
        <UserProvider> {/* Wrap routes with UserProvider */}
        <Router>
            <div className="App">
                <nav style={{ padding: '20px', backgroundColor: 'lightgray' }}>
                    <Link to="/diary" style={{ marginRight: '10px' }}>Create New Entry</Link>
                    <Link to="/entries">View All My Entries</Link>
                </nav>
                <Routes>
                    <Route path="/" element={<LandingPage />} />
                    <Route path="/signup" element={<SignUp />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/diary" element={<DiaryPage/>} />
                    <Route path="/entries" element={<ViewEntries/>} />
                </Routes>
            </div>
        </Router>
        </UserProvider>
    );
}

export default App;